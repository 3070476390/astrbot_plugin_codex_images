"""AstrBot Codex Images plugin."""
